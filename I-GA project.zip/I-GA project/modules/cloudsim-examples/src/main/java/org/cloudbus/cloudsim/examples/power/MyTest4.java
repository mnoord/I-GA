package org.cloudbus.cloudsim.examples.power;
//
//import org.cloudbus.cloudsim.Host;
//import org.cloudbus.cloudsim.Vm;
//import org.jetbrains.annotations.NotNull;
//
//import java.util.HashSet;
//import java.util.List;
//import java.util.Set;
//
//public class Mytest3 {
//    public static void main(String[] args) {
//
//    }
//
//    private static Set initialPop(@NotNull Set<Vm> vmSet, Set<Host> hostSet,
//                                  double rRam, double rCpu, double cRam, double cCpu, int popSize) {
//        Set POP = new HashSet();
//        int[] chromosome = new int[vmSet.size()];
//
//        for (int i = 0; i < popSize; ++i) {
//            chromosome =  RandomSolution (vmSet, hostSet, rRam, rCpu, cRam, cCpu);
//            POP.add(chromosome);
//        }
//        return POP;
//    }
//    private static int[] RandomSolution (@NotNull Set<Vm> vmSet, Set<Host> hostSet,
//                                         double rRam, double rCpu, double cRam, double cCpu) {
//        int[] chromosome = new int[vmSet.size()];
//
//        return chromosome;
//    }
//
//}



import org.cloudbus.cloudsim.*;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.provisioners.BwProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.PeProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;

import java.util.*;

import static org.cloudbus.cloudsim.examples.power.Helper.createBroker;
import static org.cloudbus.cloudsim.examples.power.Helper.printCloudletList;

//task
//1.创建1个Datacenter
//2.创建1台主机
//3.创建4台虚拟机
//4.创建15个任务
//5.设计顺序和逆序任务调度算法

public class MyTest4 {
    private static List<Cloudlet> cloudletList;
    private static List<Vm> vmlist;
    private static int vmNum=10; //虚拟机总数
    private static int cloudletNum=15; //任务总数

    public static void main(String[] args) {
        Log.printLine("Starting MyTest2...");
        try {
            // 1: 初始化CloudSim工具包
            int num_user = 1;                               // number of cloud users
            Calendar calendar = Calendar.getInstance();     // Calendar whose fields have been initialized with the current date and time.
            boolean trace_flag = false;                     // trace events
            CloudSim.init(num_user, calendar, trace_flag);

            // 2: 创建Datacenters
            Datacenter datacenter = createDatacenter("Datacenter_0");

            // 3: 创建Broker
            DatacenterBroker broker = createBroker();
            int brokerId = broker.getId();

            //4.创建一个虚拟机列表，然后再创建一个虚拟机，
            //并将虚拟机添加到虚拟机列表中，然后将虚拟机列表提交到Datacenter Broker。
            vmlist = new ArrayList<Vm>();

            // VM description
            int vmid = 0;
            int mips = 0;
            long size = 10000;  // image size (MB)
            int ram = 2048;      // vm memory (MB)
            long bw = 500;
            int pesNumber = 1;  // number of cpus
            String vmm = "Xen"; // VMM name

            Random random = new Random();
            for (int i = 0; i < vmNum; ++ i) {
//                mips = random.nextInt(201) + 200; //mips在[200, 400]
                mips = 400;
                // add the VM to the vmList
                vmlist.add(new
                        Vm(vmid, brokerId, mips, pesNumber, ram, bw, size, vmm, new CloudletSchedulerTimeShared()));
                vmid++;
            }

            //打印host
            System.out.println("///////////////////vm///////////////////////");
            System.out.println("name\t\tRam\t\tCpu\t\t");
            for(int i = 0; i < 10; ++i) {
                System.out.println("Vm #" + vmlist.get(i).getId() + "\t\t"
                        + vmlist.get(i).getRam() + "\t" + vmlist.get(i).getMips());
            }
            System.out.println("//////////////////////////////////////////////");

            // submit vm list to the broker
            broker.submitVmList(vmlist);

//            int[] cl = RandomSolution(vmlist, datacenter.getHostList());
//            for(int i = 0; i < cl.length; ++i) {
//                System.out.print(cl[i]);
//            }
//            System.out.println();
            //6: 开始模拟，结束模拟
            CloudSim.startSimulation();
            CloudSim.stopSimulation();

            Log.printLine("CloudSimExample1 finished!");

            //测试交叉算法
//            Map<String, int[]> children = unifCross(new int[]{1,2,2,1,3,3,2,1},new int[]{1,2,1,2,3,1,1,2});
//            int[] children1 = children.get("children1");
//            int[] children2 = children.get("children2");

            //测试变异算法
//            int[] chromosome = new int[]{1,2,3,4,5,6,7,8,9};
//            chromosome = unifMut(chromosome);

            //测试适应度函数
//            System.out.println(subFitnessFirst(new int[]{1,2,3,1,2,3,7,8,9}));
//            System.out.println(subFitnessSecond(new int[]{1, 2, 3}, datacenter.getHostList()));

        } catch (Exception e) {
            e.printStackTrace();
            Log.printLine("Unwanted errors happen");
        }
    }

    private static Datacenter createDatacenter(String name) {
        //1.创建Host列表
        List<Host> hostList = new ArrayList<Host>();

        //2.创建PE(CPU)处理器列表
        Random random = new Random();
        int mips = 800;
        List<Pe> peList1 = new ArrayList<Pe>();
        List<Pe> peList2 = new ArrayList<Pe>();
        List<Pe> peList3 = new ArrayList<Pe>();
        List<Pe> peList4 = new ArrayList<Pe>();
        List<Pe> peList5 = new ArrayList<Pe>();
        List<Pe> peList6 = new ArrayList<Pe>();
//        mips = random.nextInt(401) + 800; //mips在[800, 1200]
        peList1.add(new Pe(0, new PeProvisionerSimple(mips))); // need to store Pe id and MIPS Rating
//        mips = random.nextInt(401) + 800; //mips在[800, 1200]
        peList2.add(new Pe(1, new PeProvisionerSimple(mips))); // need to store Pe id and MIPS Rating
//        mips = random.nextInt(401) + 800; //mips在[800, 1200]
        peList3.add(new Pe(0, new PeProvisionerSimple(mips))); // need to store Pe id and MIPS Rating
//        mips = random.nextInt(401) + 800; //mips在[800, 1200]
        peList4.add(new Pe(0, new PeProvisionerSimple(mips))); // need to store Pe id and MIPS Rating
//        mips = random.nextInt(401) + 800; //mips在[800, 1200]
        peList5.add(new Pe(0, new PeProvisionerSimple(mips))); // need to store Pe id and MIPS Rating
//        mips = random.nextInt(401) + 800; //mips在[800, 1200]
        peList6.add(new Pe(0, new PeProvisionerSimple(mips))); // need to store Pe id and MIPS Rating

        //4.创建Host，并将其添加至Host列表
        int hostId = 0;
        long storage = 1000000; // host storage
        int bw = 10000; //host bandwidth

        int ram = 4096;
//        ram = 1024 * (random.nextInt(13) + 4); // Ram在[4G, 16G]
        hostList.add(
                new Host(
                        hostId,
                        new RamProvisionerSimple(ram),
                        new BwProvisionerSimple(bw),
                        storage,
                        peList1,
                        new VmSchedulerTimeShared(peList1)
                )
        );
//        ram = 1024 * (random.nextInt(13) + 4); // Ram在[4G, 16G]
        hostList.add(
                new Host(
                        hostId+1,
                        new RamProvisionerSimple(ram),
                        new BwProvisionerSimple(bw),
                        storage,
                        peList2,
                        new VmSchedulerTimeShared(peList2)
                )
        );
//        ram = 1024 * (random.nextInt(13) + 4); // Ram在[4G, 16G]
        hostList.add(
                new Host(
                        hostId+2,
                        new RamProvisionerSimple(ram),
                        new BwProvisionerSimple(bw),
                        storage,
                        peList3,
                        new VmSchedulerTimeShared(peList3)
                )
        );
//        ram = 1024 * (random.nextInt(13) + 4); // Ram在[4G, 16G]
        hostList.add(
                new Host(
                        hostId+3,
                        new RamProvisionerSimple(ram),
                        new BwProvisionerSimple(bw),
                        storage,
                        peList4,
                        new VmSchedulerTimeShared(peList4)
                )
        );
//        ram = 1024 * (random.nextInt(13) + 4); // Ram在[4G, 16G]
        hostList.add(
                new Host(
                        hostId+4,
                        new RamProvisionerSimple(ram),
                        new BwProvisionerSimple(bw),
                        storage,
                        peList5,
                        new VmSchedulerTimeShared(peList5)
                )
        );
//        ram = 1024 * (random.nextInt(13) + 4); // Ram在[4G, 16G]
        hostList.add(
                new Host(
                        hostId+5,
                        new RamProvisionerSimple(ram),
                        new BwProvisionerSimple(bw),
                        storage,
                        peList6,
                        new VmSchedulerTimeShared(peList6)
                )
        );


        //打印host
        System.out.println("///////////////////host///////////////////////");
        System.out.println("name\t\tRam\t\tCpu\t\t");
        for(int i = 0; i < 6; ++i) {
            System.out.println("Host #" + hostList.get(i).getId() + "\t\t"
                    + hostList.get(i).getRam() + "\t" + hostList.get(i).getTotalMips());
        }
        System.out.println("//////////////////////////////////////////////");

        //5.创建DatacenterCharacteristics，它表示了数据中心的资源的静态属性，
        //比如：体系结构，操作系统，主机列表，分配策略，时间或空间共享，时区，价格
        String arch = "x86";        // system architecture
        String os = "Linux";        // operating system
        String vmm = "Xen";
        double time_zone = 10.0;        // time zone this resource located
        double cost = 3.0;              // the cost of using processing in this resource
        double costPerMem = 0.05;       // the cost of using memory in this resource
        double costPerStorage = 0.001;  // the cost of using storage in this resource
        double costPerBw = 0.0;         // the cost of using bw in this resource
        LinkedList<Storage> storageList = new LinkedList<Storage>(); // we are not adding SAN devices by now

        DatacenterCharacteristics characteristics = new DatacenterCharacteristics(
                arch, os, vmm, hostList, time_zone, cost, costPerMem,
                costPerStorage, costPerBw);

        //6.创建Datacenter
        Datacenter datacenter = null;
        try {
            datacenter = new Datacenter(name, characteristics, new VmAllocationPolicySimple(hostList), storageList, 0);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return datacenter;
    }

    private static Set initialPop(List<Vm> vmList, List<Host> hostList,
                                  double[] rRam, double[] rCpu, double[] cRam, double[] cCpu, int size) {
        Set POP = new HashSet();
        int[] chromosome = new int[vmList.size()];

        for (int i = 0; i < size; ++i) {
            chromosome =  RandomSolution (vmList, hostList, rRam, rCpu, cRam, cCpu);
            POP.add(chromosome);
        }
        return POP;
    }

    private static int[] RandomSolution (List<Vm> vmList, List<Host> hostList,
                                         double[] rRam, double[] rCpu, double[] cRam, double[] cCpu) {
        int[] chromosome = new int[vmList.size()];
        Random random = new Random();

        for (int i = 0; i < vmList.size(); ++i) {
            int idx = 0;
            do {
                idx = random.nextInt(1);
            } while(hostList.get(idx).getAvailableMips() < vmList.get(i).getMips());
            chromosome[i] = idx;
        }
        return chromosome;
    }

    private static Map<String, int[]> unifCross(int[] parent1, int[] parent2) {
        Map<String, int[]> children = new HashMap<String, int[]>();
        int[] children1 = new int[parent1.length];
        int[] children2 = new int[parent2.length];
        int[] parent = new int[parent1.length + parent2.length];
        for(int i = 0; i < parent1.length; ++i){
            parent[i] = parent1[i];
        }
        for(int i = 0; i < parent2.length; ++i){
            parent[parent1.length + i] = parent2[i];
        }
        parent = disrupt(parent);
        for (int i = 0; i < parent1.length; ++i) {
            children1[i] = parent[i];
        }
        for (int i = parent1.length; i < parent.length; ++i) {
            children2[i - parent1.length] = parent[i];
        }
        children.put("children1", children1);
        children.put("children2", children2);
        return children;
    }
    private static int[] disrupt(int arr[]) { //将数组随机打乱
        int arrTemp[] = new int[arr.length];
        int size = arr.length-1;
        Random rd = new Random();
        for(int i = 0 ; i < arr.length ; i++) {
            int rand = rd.nextInt(size+1);
            arrTemp[i] = arr[rand];
            arr[rand] = arr[size];
            size--;
        }
        return arrTemp;
    }

    /*
        input:      染色体数组
        output:     突变染色体数组
        function :  依概率突交换染色体基因
    */
    private static  int[] unifMut(int[] chromosome) {
        int i, k, aux;
        float u;
        int[] mutatedChromosome = new int[chromosome.length];

        Random random = new Random();//默认构造方法
        k = chromosome.length;
        for(int j = 0; j < k; ++j) {
            mutatedChromosome[j] = chromosome[j];
        }
        while(k > 0) {
            u = random.nextFloat(); //[0,1)
            i = (int)(k*u);
            aux = mutatedChromosome[k - 1];
            mutatedChromosome[k - 1] = mutatedChromosome[i];
            mutatedChromosome[i] = aux;
            --k;
        }
        return mutatedChromosome;
    }

    /*
            input:      染色体数组
            output:     开启的host数量
            function :  计算开启的host数量
    */
    private static  int subFitnessFirst(int[] chromosome) {
        Set<Integer> set = new HashSet<Integer>();
        for (int i = 0; i < chromosome.length; ++i) {
            set.add(chromosome[i]);
        }
        return set.size();
    }

    /*
            input:      host
            output:     资源浪费率
            function :  计算当前host的资源浪费率
    */
    private static double wastage(Host host) {
        double Lcpu, Lram; //同一服务器中标准化的剩余CPU和RAM
        double Ucpu, Uram; //服务器使用的规范化CPU和RAM资源
        double e =  0.0001;

        Lcpu = host.getAvailableMips();
        Lram = host.getRamProvisioner().getAvailableRam();
        Ucpu = host.getTotalMips();
        Uram = host.getRam();

        double w = (Math.abs(Lcpu - Lram) + e) / (Ucpu + Uram);
        return w;
    }

    /*
            input:      染色体数组
            output:     资源浪费率
            function :  计算当前染色体的资源浪费率
    */
    private static double subFitnessSecond(int[] chromosome, List<Host> hostList) {
        Set<Integer> set1 = new HashSet<Integer>();
        Set<Integer> set2 = new HashSet<Integer>();

        for (int i = 0; i < chromosome.length; ++i) {
            set1.add(chromosome[i]);
        }
        for (int i = 0; i < hostList.size(); ++i) {
            set2.add(hostList.get(i).getId());
        }
        set1.retainAll(set2);

        double w = 0;
        Iterator<Integer> iterator = set1.iterator();
        while (iterator.hasNext()){
            w += wastage(hostList.get(iterator.next()));
        }
        return w;
    }

    /*
            input:      染色体数组
            output:     资源浪费率
            function :  全局适应度函数
    */
    private static double globalFitness(int[] chromosome, List<Host> hostList) {
        double Fitness1 = subFitnessFirst(chromosome);
        double Fitness2 = subFitnessSecond(chromosome, hostList);
        return (Fitness1 + Fitness2) / 2;
    }

    /*
         input:      已经激活的host(包含host已经使用的资源)，资源使用阈值
         output:     True/False， true代表需要启动负载均衡，加入新的host
         function :  判断当前是否需要负载均衡
    */
    private static Boolean migrateVMs(List<Host> activeHosts , double maxRAM, double maxCPU) {
        Boolean migrate = false;
        for (int i = 0; i < activeHosts.size(); ++i) {
            if((activeHosts.get(i).getTotalMips() - activeHosts.get(i).getAvailableMips()) > maxCPU
                    || (activeHosts.get(i).getRam() - activeHosts.get(i).getRamProvisioner().getAvailableRam()) > maxRAM)
                migrate = true;
        }
        return migrate;
    }

    /*
            input:      交叉或变异概率p
            output:     1(变异)/0(无变异)
            function :  判断是否交叉或变异
    */
    private static int Bernoulli_ITM(double p) {
        Random random = new Random();
        int X;
        double u = random.nextDouble();
        if(u <= p)
            X = 1;
        else
            X = 0;
        return X;
    }

//    private static int[] GAVMP_BO (List<Vm> vmList, List<Host> hostList,
//                                         double[] rRam, double[] rCpu, double[] cRam, double[] cCpu) {
//        int N; //迭代数
//        double crossRate; //交叉率
//        double mutRate; //变异率
//        int X; //伯努利分配结果
//        Set POP = new HashSet(); //初始种群集
//        int size; //种群大小
//
//        int[] parentChrom1 = new int[vmList.size()];
//        int[] parentChrom2 = new int[vmList.size()];
//        double fitness = 0;
//        double bestFitnessScore = 0;
//        double u;
//
//        for (int i = 0; i < hostList.size(); ++i)
//            bestFitnessScore += wastage(hostList.get(i));
//
//        POP = initialPop(vmList, hostList, rRam, rCpu, cRam, cCpu, size);
//
//        int[] C = new int[vmList.size()]; //最佳非支配解
//
//        List<Host> activeHosts = new ArrayList<Host>();
//        double maxRAM, maxCPU;
//        while(migrateVMs(activeHosts, maxRAM, maxCPU)) {
//            for(int i = 0; i < N; ++i) {
//            }
//        }
//    }
}
