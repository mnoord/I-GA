package org.cloudbus.cloudsim.examples;

import org.cloudbus.cloudsim.*;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.provisioners.BwProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.PeProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;
import org.cloudbus.cloudsim.util.Vmp;
import java.util.Collections;

import java.util.*;

import static org.cloudbus.cloudsim.examples.power.Helper.createBroker;

public class I_GAMain {

    private static List<Vm> vmlist;
    private static int vmNum = 20; //虚拟机总数
    private static int hostNum = 16; //物理机机总数

    public static void main(String[] args) {
        int popSize = 20; //种群数
        int iterateNum = 5; //迭代数
        double probability = 2.0; //交叉变异率
        int H = 1; //单虚拟机最多放置组数量
        Vmp finalVmp = IGA(popSize, iterateNum, probability, H);
        System.out.println("##############################");
        System.out.println("final Vmp");
        for (int i = 0; i < finalVmp.codes.length; i++) {
            System.out.print(finalVmp.codes[i] + " ");
        }
        System.out.println("\n##############################");

    }

    private static Datacenter VHAM(List<Integer> vmMipsList, List<Integer> vmRamList,
                                   List<Integer> hostMipsList, List<Integer> hostRamList,
                                   List<Double> hostAvaList, int H) {
        Log.printLine("Starting VHAM...");
        try {
            // 1: 初始化CloudSim工具包
            int num_user = 1;                               // number of cloud users
            Calendar calendar = Calendar.getInstance();     // Calendar whose fields have been initialized with the current date and time.
            boolean trace_flag = false;                     // trace events
            CloudSim.init(num_user, calendar, trace_flag);

            // 2: 创建Datacenters
            Datacenter datacenter = createDatacenter("Datacenter_0", hostMipsList, hostRamList, hostAvaList);
            // 3: 创建Broker
            DatacenterBroker broker = createBroker();
            int brokerId = broker.getId();
            //4.创建一个虚拟机列表，然后再创建一个虚拟机，
            //并将虚拟机添加到虚拟机列表中，然后将虚拟机列表提交到Datacenter Broker。
            vmlist = new ArrayList<Vm>();
            // VM description
            int vmid = 0;
//            int mips = 2000;
            long size = 10000;  // image size (MB)
//            int ram = 1024;      // vm memory (MB)
            long bw = 500;
            int pesNumber = 1;  // number of cpus
            String vmm = "Xen"; // VMM name

            for (int i = 0; i < vmNum * H; ++i) {
                // add the VM to the vmList
                vmlist.add(new
                        Vm(vmid, brokerId, vmMipsList.get(i), pesNumber, vmRamList.get(i), bw, size, vmm, new CloudletSchedulerTimeShared()));
                vmid++;
            }
            //打印vm
            System.out.println("///////////////////vm///////////////////////");
            System.out.println("name\t\tRam\t\tCpu\t\t");
            for (int i = 0; i < vmNum * H; ++i) {
                System.out.println("Vm #" + vmlist.get(i).getId() + "\t\t"
                        + vmlist.get(i).getRam() + "\t" + vmlist.get(i).getMips());
            }
            System.out.println("//////////////////////////////////////////////");

            // submit vm list to the broker
            broker.submitVmList(vmlist);

            //6: 开始模拟，结束模拟
            CloudSim.startSimulation();
            CloudSim.stopSimulation();
            Log.printLine("VHAM finished!");

            return datacenter;
        } catch (Exception e) {
            e.printStackTrace();
            Log.printLine("The VHAM has been terminated due to an unexpected error");
        }
        return null;
    }

    private static Datacenter createDatacenter(String name, List<Integer> hostMipsList,
                                               List<Integer> hostRamList, List<Double> hostAvaList) {
        //1.创建Host列表
        List<Host> hostList = new ArrayList<Host>();

        //2.创建PE(CPU)处理器列表
//        int mips = 4000;
        List<List<Pe>> peLists = new ArrayList<List<Pe>>();
        for (int i = 0; i < hostNum; ++i) {
            List<Pe> peList = new ArrayList<Pe>();
            peList.add(new Pe(0, new PeProvisionerSimple(hostMipsList.get(i))));
            peLists.add(peList);
        }

        //4.创建Host，并将其添加至Host列表
        int hostId = 0;
        long storage = 1000000; // host storage
        int bw = 10000; //host bandwidth
//        int ram = 2048;
        for (int i = 0; i < hostNum; ++i) {
            hostList.add(
                    new Host(
                            hostId + i,
                            new RamProvisionerSimple(hostRamList.get(i)),
                            new BwProvisionerSimple(bw),
                            storage,
                            peLists.get(i),
                            new VmSchedulerTimeShared(peLists.get(i)),
                            hostAvaList.get(i)
                    ));
        }

        //打印host
        System.out.println("///////////////////host///////////////////////");
        System.out.println("name\t\tRam\t\tCpu\t\t");
        for (int i = 0; i < hostNum; ++i) {
            System.out.println("Host #" + hostList.get(i).getId() + "\t\t"
                    + hostList.get(i).getRam() + "\t" + hostList.get(i).getTotalMips());
        }
        System.out.println("//////////////////////////////////////////////");

        //5.创建DatacenterCharacteristics，它表示了数据中心的资源的静态属性，
        //比如：体系结构，操作系统，主机列表，分配策略，时间或空间共享，时区，价格
        String arch = "x86";        // system architecture
        String os = "Linux";        // operating system
        String vmm = "Xen";
        double time_zone = 10.0;        // time zone this resource located
        double cost = 3.0;              // the cost of using processing in this resource
        double costPerMem = 0.05;       // the cost of using memory in this resource
        double costPerStorage = 0.001;  // the cost of using storage in this resource
        double costPerBw = 0.0;         // the cost of using bw in this resource
        LinkedList<Storage> storageList = new LinkedList<Storage>(); // we are not adding SAN devices by now
        DatacenterCharacteristics characteristics = new DatacenterCharacteristics(
                arch, os, vmm, hostList, time_zone, cost, costPerMem,
                costPerStorage, costPerBw);

        //6.创建Datacenter
        Datacenter datacenter = null;
        try {
            datacenter = new Datacenter(name, characteristics, new VmAllocationPolicySimple(hostList), storageList, 0);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return datacenter;
    }

    private static void showAllocation(Datacenter datacenter) {
        List<Host> hostlist = datacenter.getHostList();
        for (int i = 0; i < hostlist.size(); i++) {
            System.out.print("Host" + i + ": ");
            List<Vm> vmlist = hostlist.get(i).getVmList();
            if (!vmlist.isEmpty()) {
                for (int j = 0; j < vmlist.size(); j++) {
                    System.out.print(vmlist.get(j).getId() + " ");
                }
                System.out.println();
            } else {
                System.out.println();
            }
        }
    }

    public static Vmp IGA(int popSize, int iterateNum, double probability, int H) {
        HashSet<Vmp> X = new HashSet<Vmp>();
        Random random = new Random(System.currentTimeMillis());
        Datacenter datacenter = null;
        List<Integer> vmMipsList = new ArrayList<>();
        List<Integer> vmRamList = new ArrayList<>();
        List<Integer> hostMipsList = new ArrayList<>();
        List<Integer> hostRamList = new ArrayList<>();
        List<Double> hostAvaList = new ArrayList<>();

        List<Integer> tempVmMipsList = new ArrayList<>();
        List<Integer> tempVmRamList = new ArrayList<>();
        for (int j = 0; j < vmNum; j++) {
            int mips = random.nextInt(201) + 200; //mips在[200, 400]
            int ram = 1024 * (random.nextInt(3) + 2); // Ram在[2G, 4G]
            tempVmMipsList.add(mips);
            tempVmRamList.add(ram);
        }
        for (int i = 0; i < H; i++) {
            vmMipsList.addAll(tempVmMipsList);
            vmRamList.addAll(tempVmRamList);
        }

        double ab[] = {0.99, 0.999, 0.9995, 0.9999};
        for (int i = 0; i < hostNum; i++) {
            int mips = random.nextInt(401) + 800; //mips在[800, 1200]
            int ram = 1024 * (random.nextInt(9) + 8); // Ram在[8G, 16G]
            double a = ab[random.nextInt(4)];
            hostMipsList.add(mips);
            hostRamList.add(ram);
            hostAvaList.add(a);
        }

        for (int i = 0; i < popSize; ++i) {
            datacenter = VHAM(vmMipsList, vmRamList, hostMipsList, hostRamList, hostAvaList, H);
            showAllocation(datacenter);

            Vmp vmp = new Vmp(datacenter.getVmList().size());

            // 获取host上的vms，生成vmp
            List<Host> hostlist = datacenter.getHostList();
            for (int j = 0; j < hostlist.size(); j++) {
                List<Vm> vmlist = hostlist.get(j).getVmList();
                if (!vmlist.isEmpty()) {
                    for (int k = 0; k < vmlist.size(); k++) {
                        vmp.codes[vmlist.get(k).getId()] = hostlist.get(j).getId();
                    }
                }
            }
            X.add(vmp);
        }
        double Emin = Double.MAX_VALUE ; //能耗最小值
        Iterator<Vmp> it = X.iterator();
        while (it.hasNext()) {
            Vmp a = it.next();
            double e =  EC(a, datacenter);
            if(Emin > e) {
                Emin = e;
            }
        }

        System.out.println("#############################");
        System.out.println("Initialization");
        it = X.iterator();
        while (it.hasNext()) {
            Vmp a = it.next();
            for (int j = 0; j < a.codes.length; j++) {
                System.out.print(a.codes[j] + " ");
            }
            System.out.println();
        }
        System.out.println("#############################");

        int t = 0;
        double u = 0.0;
        while (t < iterateNum) {
            // Crossover
            random = new Random(System.currentTimeMillis());
            u = random.nextDouble();
            if (u <= probability) {
                List<Vmp> Xl = new ArrayList<>(X);
                Set<Vmp> set = Cross(Xl.get(0), Xl.get(1), datacenter, H);
                Iterator<Vmp> ite = set.iterator();
                while (ite.hasNext()) {
                    X.add(ite.next());
                }
                List<Vmp> xList = G_T(X, datacenter.getHostList(), H, popSize, Emin, datacenter);
                X = new HashSet<>(xList);
            }

            System.out.println("#############################");
            System.out.println("Crossover");
            it = X.iterator();
            while (it.hasNext()) {
                Vmp a = it.next();
                for (int j = 0; j < a.codes.length; j++) {
                    System.out.print(a.codes[j] + " ");
                }
                System.out.println();
            }
            System.out.println("#############################");

            // Mutation
            int times = X.size();
            for (int i = 0; i < times; ++i) {
                u = random.nextDouble();
                if (u <= probability) {
                    List<Vmp> Xl = new ArrayList<>(X);
                    X.add(Mutate(Xl.get(i), datacenter, H));
                    List<Vmp> xList = G_T(X, datacenter.getHostList(), H, popSize, Emin, datacenter);
                    X = new HashSet<>(xList);
                }
            }
            System.out.println("#############################");
            System.out.println("Mutation");
            it = X.iterator();
            while (it.hasNext()) {
                Vmp a = it.next();
                for (int j = 0; j < a.codes.length; j++) {
                    System.out.print(a.codes[j] + " ");
                }
                System.out.println();
            }
            System.out.println("#############################");
            ++t;
        }

        List<Vmp> xList = G_T(X, datacenter.getHostList(), H, popSize, Emin, datacenter);
        return xList.get(0);
    }

    public static Set<Vmp> Cross(Vmp parentv1, Vmp parentv2, Datacenter datacenter, int H) {
        int[] parent1 = deepCopy(parentv1.codes);
        int[] parent2 = deepCopy(parentv2.codes);

        Random random = new Random(System.currentTimeMillis());
        int hostIdx = random.nextInt(hostNum);

        int[] oldparent1 = deepCopy(parent1);
        for (int i = 0; i < parent1.length; ++i) {
            if (parent2[i] == hostIdx) {
                parent1[i] = hostIdx;
                parent2[i] = -1;
            }
        }
        for (int i = 0; i < parent2.length; ++i) {
            if (oldparent1[i] == hostIdx) {
                parent2[i] = hostIdx;
                parent1[i] = -1;
            }
        }

        int[] cRam = new int[hostNum];
        int[] cCpu = new int[hostNum];
        List<Host> hostList = datacenter.getHostList();
        for (int i = 0; i < hostList.size(); i++) {
            int idx = hostList.get(i).getId();
            cRam[idx] = hostList.get(i).getRamProvisioner().getRam();
            cCpu[idx] = hostList.get(i).getTotalMips();
        }

        int rRam[] = new int[vmNum*H];
        int rCpu[] = new int[vmNum*H];
        List<Vm> vmList = datacenter.getVmList();
        for (int i = 0; i < vmList.size(); i++) {
            int idx = vmList.get(i).getId();
            rRam[idx] = vmList.get(i).getRam();
            rCpu[idx] = (int) vmList.get(i).getMips();
        }

        int[] tempRam = deepCopy(cRam);
        int[] tempCpu = deepCopy(cCpu);
        for (int i = 0; i < parent1.length; ++i) {
            if (-1 != parent1[i]) {
                tempRam[parent1[i]] -= rRam[i];
                tempCpu[parent1[i]] -= rCpu[i];
            }
        }
        for (int i = 0; i < parent1.length; ++i) {
            if (-1 == parent1[i]) {
                for (int j = 0; j < hostNum; ++j) {
                    if (tempRam[j] - rRam[i] >= 0 && tempCpu[j] - rCpu[i] >= 0) {
                        parent1[i] = j;
                        break;
                    }
                }
            }
        }
        tempRam = deepCopy(cRam);
        tempCpu = deepCopy(cCpu);
        for (int i = 0; i < parent2.length; ++i) {
            if (-1 != parent2[i]) {
                tempRam[parent2[i]] -= rRam[i];
                tempCpu[parent2[i]] -= rCpu[i];
            }
        }
        for (int i = 0; i < parent2.length; ++i) {
            if (-1 == parent2[i]) {
                for (int j = 0; j < hostNum; ++j) {
                    if (tempRam[j] - rRam[i] >= 0 && tempCpu[j] - rCpu[i] >= 0) {
                        parent2[i] = j;
                        break;
                    }
                }
            }
        }

        Set<Vmp> set = new HashSet<Vmp>();
        set.add(new Vmp(parent1));
        set.add(new Vmp(parent2));
        return set;
    }

    private static int[] deepCopy(int[] originalArr) {
        int[] newArr = new int[originalArr.length];
        for (int i = 0; i < originalArr.length; ++i) {
            newArr[i] = originalArr[i];
        }
        return newArr;
    }

    public static Vmp Mutate(Vmp vmp, Datacenter datacenter, int H) {
        //找到变异主机簇
        List<Host> hostList = datacenter.getHostList();
        int[] cRam = new int[hostNum];
        int[] cCpu = new int[hostNum];
        for (int i = 0; i < hostList.size(); i++) {
            int idx = hostList.get(i).getId();
            cRam[idx] = hostList.get(i).getRamProvisioner().getRam();
            cCpu[idx] = hostList.get(i).getTotalMips();
        }

        int rRam[] = new int[vmNum*H];
        int rCpu[] = new int[vmNum*H];
        List<Vm> vmList = datacenter.getVmList();
        for (int i = 0; i < vmList.size(); i++) {
            int idx = vmList.get(i).getId();
            rRam[idx] = vmList.get(i).getRam();
            rCpu[idx] = (int) vmList.get(i).getMips();
        }

        double minf = 1.0f;
        int idx = -1;
        for (int i = 0; i < hostList.size(); ++i) {
            double f = MutateFunc(hostList.get(i), vmp, rRam, rCpu, cRam, cCpu);
            if (f < minf) {
                minf = f;
                idx = i;
            }
        }
        //保存变异主机簇上已经放置的虚拟机
        List<Vm> vms = new ArrayList<Vm>();
        for (int i = 0; i < vmp.codes.length; ++i) {
            if (vmp.codes[i] == idx) {
                vms.add(vmlist.get(i));
            }
        }
        int[] tempRam = deepCopy(cRam);
        int[] tempCpu = deepCopy(cCpu);
        for (int i = 0; i < vmp.codes.length; ++i) {
            tempRam[vmp.codes[i]] -= rRam[i];
            tempCpu[vmp.codes[i]] -= rCpu[i];
        }

        //将虚拟机重新放置
        int hosti = -1, vmi = -1;
        for (int i = 0; i < vms.size(); ++i) {
            boolean flag = false;
            do {
                Random random = new Random(System.currentTimeMillis());
                hosti = random.nextInt(hostNum);
                vmi = vms.get(i).getId();
                if (tempRam[hosti] - rRam[vmi] >= 0 && tempCpu[hosti] - rCpu[vmi] >= 0) {
                    tempRam[hosti] -= rRam[vmi];
                    tempCpu[hosti] -= rCpu[vmi];
                    vmp.codes[vmi] = hosti;
                    flag = true;
                }
            } while (hosti == idx || !flag);
        }
        return vmp;
    }

    private static double MutateFunc(Host host, Vmp vmp, int[] rRam, int[] rCpu, int[] cRam, int[] cCpu) {
        int idx = host.getId();
        int[] tempRam = deepCopy(cRam);
        int[] tempCpu = deepCopy(cCpu);
        boolean flag = false;
        for (int i = 0; i < vmp.codes.length; ++i) {
            if (vmp.codes[i] == idx) {
                tempRam[idx] -= rRam[i];
                tempCpu[idx] -= rCpu[i];
                flag = true;
            }
        }
        if (!flag)
            return 1.0;
        double Lcpu = (double) tempCpu[idx] / cCpu[idx];
        double Lram = (double) tempRam[idx] / cRam[idx];
        double Ucpu = (double) (cCpu[idx] - tempCpu[idx]) / cCpu[idx];
        double URam = (double) (cRam[idx] - tempRam[idx]) / cRam[idx];

        double f = (Math.abs(Lcpu - Lram) + 0.0001) / (Ucpu + URam);
        return f;
    }

    private static double singleA(Vmp vmp, List<Host> hostList) {
        double a = 1.0;
        Set<Integer> set = new HashSet<>();
        for (int i = 0; i < vmp.codes.length; i++) {
            set.add(vmp.codes[i]);
        }
        Iterator<Integer> it = set.iterator();
        while (it.hasNext()) {
            a *= hostList.get(it.next()).getAbility();
        }
        return a;
    }

    private static double fullA(Vmp vmp, List<Host> hostList, int H) {
        int size = vmp.codes.length / H;
        double a = 1.0;
        for (int i = 0; i < H; i++) {
            double aa = 1.0;
            Set<Integer> hostSet = new HashSet<>();
            for (int j = 0; j < size; j++) {
                hostSet.add(vmp.codes[size * i + j]);
            }
            Iterator<Integer> it = hostSet.iterator();
            while (it.hasNext()) {
                aa *= hostList.get(it.next()).getAbility();
            }
            a *= 1 - aa;
        }
        return 1 - a;
    }

    private static double partialA(Vmp vmp, List<Host> hostList, int H) {
        int size = vmp.codes.length / H;
        if (2 == H) {
            double a = 1.0;
            double a1 = 1.0;
            double a2 = 1.0;
            Set<Integer> hostSet = new HashSet<>();
            Set<Integer> hostSet1 = new HashSet<>();
            Set<Integer> hostSet2 = new HashSet<>();

            for (int i = 0; i < size; i++) {
                hostSet1.add(vmp.codes[i]);
                hostSet2.add(vmp.codes[size+i]);
            }
            Iterator<Integer> it = hostSet1.iterator();
            while (it.hasNext()) {
                a1 *= hostList.get(it.next()).getAbility();
            }
            it = hostSet2.iterator();
            while (it.hasNext()) {
                a2 *= hostList.get(it.next()).getAbility();
            }
            hostSet.addAll(hostSet1);
            hostSet.addAll(hostSet2);
            it = hostSet.iterator();
            while (it.hasNext()) {
                a *= hostList.get(it.next()).getAbility();
            }
            return a1+a2-a;
        } else if (3 == H) {
            double a = 1.0;
            double a1 = 1.0;
            double a2 = 1.0;
            double a3 = 1.0;
            double a4 = 1.0;
            double a5 = 1.0;
            double a6 = 1.0;

            Set<Integer> hostSet = new HashSet<>();
            Set<Integer> hostSet1 = new HashSet<>();
            Set<Integer> hostSet2 = new HashSet<>();
            Set<Integer> hostSet3 = new HashSet<>();
            Set<Integer> hostSet4 = new HashSet<>();
            Set<Integer> hostSet5 = new HashSet<>();
            Set<Integer> hostSet6 = new HashSet<>();

            for (int i = 0; i < size; i++) {
                hostSet1.add(vmp.codes[i]);
                hostSet2.add(vmp.codes[size+i]);
                hostSet3.add(vmp.codes[size*2+i]);
            }
            hostSet4.addAll(hostSet1);
            hostSet4.addAll(hostSet2);
            hostSet5.addAll(hostSet1);
            hostSet5.addAll(hostSet3);
            hostSet6.addAll(hostSet2);
            hostSet6.addAll(hostSet3);

            hostSet.addAll(hostSet1);
            hostSet.addAll(hostSet2);
            hostSet.addAll(hostSet3);

            Iterator<Integer> it = hostSet1.iterator();
            while (it.hasNext()) {
                a1 *= hostList.get(it.next()).getAbility();
            }
            it = hostSet2.iterator();
            while (it.hasNext()) {
                a2 *= hostList.get(it.next()).getAbility();
            }
            it = hostSet3.iterator();
            while (it.hasNext()) {
                a3 *= hostList.get(it.next()).getAbility();
            }
            it = hostSet4.iterator();
            while (it.hasNext()) {
                a4 *= hostList.get(it.next()).getAbility();
            }
            it = hostSet5.iterator();
            while (it.hasNext()) {
                a5 *= hostList.get(it.next()).getAbility();
            }
            it = hostSet6.iterator();
            while (it.hasNext()) {
                a6 *= hostList.get(it.next()).getAbility();
            }
            return a1+a2+a3-a4-a5-a6+a;
        }
        return 0.0;
    }

    private static List<Vmp> G_T(HashSet<Vmp> X, List<Host> hostList, int H, int popSize,
                                 double Emin, Datacenter datacenter) {
        List<Vmp> listX = new ArrayList<>(X);
        Map<Vmp, Double> mapX = new HashMap<>();
        for (int i = 0; i < listX.size(); i++) {
            if(1 == H) {
                mapX.put(listX.get(i), 0.5*(Emin/EC(listX.get(i), datacenter)+singleA(listX.get(i), hostList)));
            }
            else if(2 == H) {
                Boolean partial = false;
                int size = listX.get(i).codes.length / H;
                for (int j = 0; j < size; j++) {
                    if(listX.get(i).codes[j] == listX.get(i).codes[size+j]) {
                        partial = true;
                        break;
                    }
                }
                if (partial) {
                    mapX.put(listX.get(i), 0.5*(Emin/EC(listX.get(i), datacenter)+partialA(listX.get(i), hostList, H)));
                } else {
                    mapX.put(listX.get(i), 0.5*(Emin/EC(listX.get(i), datacenter)+fullA(listX.get(i), hostList, H)));
                }
            }
            else if(3 == H) {
                Boolean partial = false;
                int size = listX.get(i).codes.length / H;
                for (int j = 0; j < size; j++) {
                    if(listX.get(i).codes[j] == listX.get(i).codes[size+j]
                    || listX.get(i).codes[j] == listX.get(i).codes[size*2+j]
                    || listX.get(i).codes[size+j] == listX.get(i).codes[size+j]){
                        partial = true;
                        break;
                    }
                }
                if (partial) {
                    mapX.put(listX.get(i), 0.5*(Emin/EC(listX.get(i), datacenter)+partialA(listX.get(i), hostList, H)));
                } else {
                    mapX.put(listX.get(i), 0.5*(Emin/EC(listX.get(i), datacenter)+fullA(listX.get(i), hostList, H)));
                }
            }
        }

        // 降序比较器
        Comparator<Map.Entry<Vmp, Double>> valueComparator = new Comparator<Map.Entry<Vmp,Double>>() {
            @Override
            public int compare(Map.Entry<Vmp, Double> o1,
                               Map.Entry<Vmp, Double> o2) {
                if ((o2.getValue() - o1.getValue())>0)
                    return 1;
                else if((o2.getValue() - o1.getValue())==0)
                    return 0;
                else
                    return -1;
            }
        };
        List<Map.Entry<Vmp, Double>> list = new ArrayList<Map.Entry<Vmp,Double>>(mapX.entrySet());
        List<Vmp> tempList = new ArrayList<>();
        Collections.sort(list, valueComparator);
        X.clear();
        for (int i = 0; i < popSize; i++) {
            tempList.add(list.get(i).getKey());
        }
        return tempList;
    }

    //energy consumption
    private static double EC(Vmp vmp, Datacenter datacenter) {
        double c = 0.15;
        double f = 0.24;
        double k = 0.3;
        double res = 0.0;
        List<Host> hostList = datacenter.getHostList();
        for (int i = 0; i < hostList.size(); i++) {
            double useCpu = 0.0;
            double hostCpu = hostList.get(i).getTotalMips();
            double cpuUtilization;
            for (int j = 0; j < vmp.codes.length; j++) {
                if(vmp.codes[j] == hostList.get(i).getId())
                    useCpu += vmlist.get(j).getMips();
            }
            cpuUtilization = useCpu/hostCpu;
            res += c + k * Math.pow(f, 3.0) * cpuUtilization;
        }
        return res;
    }
}