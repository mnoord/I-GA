package org.cloudbus.cloudsim.util;

public class BinNode{
    public Integer val;
    public BinNode leftNode;
    public BinNode rightNode;
    public double cCpu, cRam;
    public double rCpu, rRam;
    public Integer id;
    public BinNode(Integer val) {
        this.val = val;
        this.cCpu = 0;
        this.cRam = 0;
        this.rCpu = 0;
        this.rRam = 0;

    }
    public BinNode() {
    }

    public Integer getVal() {
        return val;
    }
    public void setVal(int val) {
        this.val = val;
    }
    public BinNode getLeftNode() {
        return leftNode;
    }
    public void setLeftNode(BinNode leftNode) {
        this.leftNode = leftNode;
    }
    public BinNode getRightNode() {
        return rightNode;
    }
    public void setRightNode(BinNode rightNode) {
        this.rightNode = rightNode;
    }

}
