/*
 * Title:        CloudSim Toolkit
 * Description:  CloudSim (Cloud Simulation) Toolkit for Modeling and Simulation of Clouds
 * Licence:      GPL - http://www.gnu.org/copyleft/gpl.html
 *
 * Copyright (c) 2009-2012, The University of Melbourne, Australia
 */

package org.cloudbus.cloudsim;

import java.nio.charset.Charset;
import java.util.*;
import com.google.common.hash.Funnel;
import com.google.common.hash.Funnels;
import com.google.common.hash.Hashing;

import com.google.common.collect.Lists;
import org.cloudbus.cloudsim.core.CloudSim;

import org.cloudbus.cloudsim.util.BinNode;
import org.cloudbus.cloudsim.util.BinaryTree;
import org.cloudbus.cloudsim.util.RendezvousHash;

/**
 * VmAllocationPolicySimple is an VmAllocationPolicy that chooses, as the host for a VM, the host
 * with less PEs in use. It is therefore a Worst Fit policy, allocating VMs into the
 * host with most available PE.
 *
 * @author Rodrigo N. Calheiros
 * @author Anton Beloglazov
 * @since CloudSim Toolkit 1.0
 */
public class VmAllocationPolicySimple extends VmAllocationPolicy {

    private static int vmNum=20; //虚拟机总数
	private static int hostNum;
	private static int[] vmp;
	private static BinaryTree tree;
	//使用RendezvousHash
	private static final Funnel<CharSequence> strFunnel = Funnels.stringFunnel(Charset.defaultCharset());
    /** The map between each VM and its allocated host.
         * The map key is a VM UID and the value is the allocated host for that VM. */
	private Map<String, Host> vmTable;

	/** The map between each VM and the number of Pes used.
         * The map key is a VM UID and the value is the number of used Pes for that VM. */
	private Map<String, Integer> usedPes;

	/** The number of free Pes for each host from {@link #getHostList() }. */
	private List<Integer> freePes;

	/**
	 * Creates a new VmAllocationPolicySimple object.
	 *
	 * @param list the list of hosts
	 * @pre $none
	 * @post $none
	 */
	public VmAllocationPolicySimple(List<? extends Host> list) {
		super(list);
		setFreePes(new ArrayList<Integer>());
		for (Host host : getHostList()) {
			getFreePes().add(host.getNumberOfPes());
		}
		setVmTable(new HashMap<String, Host>());
		setUsedPes(new HashMap<String, Integer>());

		hostNum = getHostList().size();
		vmp = new int[vmNum];

		// 主机排列
		int[] hostArr = new int[hostNum];
		for(int i = 0; i < hostNum; ++i) {
			hostArr[i] = getHostList().get(i).getId();
		}

		//创建二叉树,默认物理主机簇上有4台物理主机
		Integer[] initialArr = new Integer[hostNum/2-1];
		initialArr[0] = -1;
		for(int i = 1; i < initialArr.length; ++i) {
			initialArr[i] = ((i+1)%2);
		}
		tree = new BinaryTree(initialArr);
	}

	/**
	 * Allocates the host with less PEs in use for a given VM.
	 *
	 * @param vm {@inheritDoc}
	 * @return {@inheritDoc}
	 * @pre $none
	 * @post $none
	 */
	@Override
	public boolean allocateHostForVm(Vm vm) {
		boolean result = false;
		Random random = new Random();

		if (!getVmTable().containsKey(vm.getUid())) { // if this vm was not created
			do {
				int clusterPos = 1;

				int i = vm.getId();
				List<String> nodes = Lists.newArrayList();
				for (int j = 0; j < hostNum-1; ++j)
					nodes.add(Integer.toString(random.nextInt(10)));
				RendezvousHash<String, String> h = new RendezvousHash(Hashing.murmur3_128(), strFunnel, strFunnel, nodes);
				BinNode cur = tree.root;
				while (null != cur.leftNode && null != cur.rightNode) {
					String node = h.get(getHostList().toString()+i);
					if (Integer.parseInt(node) % 2 == 0) {
						cur = cur.leftNode;
						clusterPos = clusterPos * 2;
					}
					else {
						cur = cur.rightNode;
						clusterPos = clusterPos * 2 + 1;
					}
					h.remove(node);
				}
				clusterPos = clusterPos - hostNum / 4;  //计算在第几个主机簇

				double w = -1.0;
				int hostPos = -1;
				for (int j = 0; j < 4; j++) {
					double score = F(vm, getHostList().get(clusterPos*4+j)) * Tag(vm, getHostList().get(clusterPos*4+j));
					if(w < score) {
						w = score;
						hostPos = clusterPos*4+j;
					}
				}

				Host host = getHostList().get(hostPos);
				result = host.vmCreate(vm);

				if (result) { // if vm were succesfully created in the host
					getVmTable().put(vm.getUid(), host);
					result = true;
					break;
				}
				++i;
			} while (!result);
		}
		return true;
	}

	public boolean allocateHostForVm2(Vm vm) {
		int requiredPes = vm.getNumberOfPes(); //vm需要的pes数
		boolean result = false;
		int tries = 0;
		List<Integer> freePesTmp = new ArrayList<Integer>();
		for (Integer freePes : getFreePes()) { //获取空闲的pes数
			freePesTmp.add(freePes);
		}

		if (!getVmTable().containsKey(vm.getUid())) { // if this vm was not created
			do {// we still trying until we find a host or until we try all of them
				int moreFree = Integer.MIN_VALUE;
				int idx = -1;

				// we want the host with less pes in use
				for (int i = 0; i < freePesTmp.size(); i++) {
					if (freePesTmp.get(i) > moreFree) {
						moreFree = freePesTmp.get(i);
						idx = i;
					}
				}

				Host host = getHostList().get(idx);
				result = host.vmCreate(vm);

				if (result) { // if vm were succesfully created in the host
					getVmTable().put(vm.getUid(), host);
					getUsedPes().put(vm.getUid(), requiredPes);
					getFreePes().set(idx, getFreePes().get(idx) - requiredPes);
					result = true;
					break;
				} else {
					freePesTmp.set(idx, Integer.MIN_VALUE);
				}
				tries++;
			} while (!result && tries < getFreePes().size());

		}
		return result;
	}

	@Override
	public void deallocateHostForVm(Vm vm) {
		Host host = getVmTable().remove(vm.getUid());
		int idx = getHostList().indexOf(host);
		int pes = getUsedPes().remove(vm.getUid());
		if (host != null) {
			host.vmDestroy(vm);
			getFreePes().set(idx, getFreePes().get(idx) + pes);
		}
	}

	@Override
	public Host getHost(Vm vm) {
		return getVmTable().get(vm.getUid());
	}

	@Override
	public Host getHost(int vmId, int userId) {
		return getVmTable().get(Vm.getUid(userId, vmId));
	}

	/**
	 * Gets the vm table.
	 *
	 * @return the vm table
	 */
	public Map<String, Host> getVmTable() {
		return vmTable;
	}

	/**
	 * Sets the vm table.
	 *
	 * @param vmTable the vm table
	 */
	protected void setVmTable(Map<String, Host> vmTable) {
		this.vmTable = vmTable;
	}

	/**
	 * Gets the used pes.
	 *
	 * @return the used pes
	 */
	protected Map<String, Integer> getUsedPes() {
		return usedPes;
	}

	/**
	 * Sets the used pes.
	 *
	 * @param usedPes the used pes
	 */
	protected void setUsedPes(Map<String, Integer> usedPes) {
		this.usedPes = usedPes;
	}

	/**
	 * Gets the free pes.
	 *
	 * @return the free pes
	 */
	protected List<Integer> getFreePes() {
		return freePes;
	}

	/**
	 * Sets the free pes.
	 *
	 * @param freePes the new free pes
	 */
	protected void setFreePes(List<Integer> freePes) {
		this.freePes = freePes;
	}

	@Override
	public List<Map<String, Object>> optimizeAllocation(List<? extends Vm> vmList) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean allocateHostForVm(Vm vm, Host host) {
		if (host.vmCreate(vm)) { // if vm has been succesfully created in the host
			getVmTable().put(vm.getUid(), host);

			int requiredPes = vm.getNumberOfPes();
			int idx = getHostList().indexOf(host);
			getUsedPes().put(vm.getUid(), requiredPes);
			getFreePes().set(idx, getFreePes().get(idx) - requiredPes);

			Log.formatLine(
					"%.2f: VM #" + vm.getId() + " has been allocated to the host #" + host.getId(),
					CloudSim.clock());
			return true;
		}

		return false;
	}


	public void createTree(BinNode root, int[] cRam, int[] cCpu) {
		if(root == null) {
			return;
		}
		Queue<BinNode> queue = new LinkedList<BinNode>();
		List<BinNode> list = new ArrayList<BinNode>();
		BinNode current = null;
		queue.offer(root);
		int id = -1;
		while(!queue.isEmpty()) {
			current = queue.poll();
			list.add(current);
			if (current.getLeftNode() != null) {
				queue.offer(current.getLeftNode());
			}
			if (current.getRightNode() != null) {
				queue.offer(current.getRightNode());
			}
		}
		int len = list.size();
		int idx = 0;
		for (int i = 0; i < hostNum; ++i) {
			idx = len-1-i/2;
			list.get(idx).cCpu += cCpu[hostNum-1-i];
			list.get(idx).cRam += cRam[hostNum-1-i];
		}
		for(int i = idx-1; i >= 0; --i) {
			list.get(i).cCpu += list.get(i*2+1).cCpu + list.get(i*2+2).cCpu;
			list.get(i).cRam += list.get(i*2+1).cRam + list.get(i*2+2).cRam;
		}

		for(int i = 0; i < list.size(); ++i)
			list.get(i).id = i -1;
	}

	//将数组随机打乱
	private static int[] disrupt(int arr[]) {
		int arrTemp[] = new int[arr.length];
		int size = arr.length-1;
		Random rd = new Random();
		for(int i = 0 ; i < arr.length ; i++) {
			int rand = rd.nextInt(size+1);
			arrTemp[i] = arr[rand];
			arr[rand] = arr[size];
			size--;
		}
		return arrTemp;
	}

	private static int Tag(Vm vm, Host host) {
		int i = vm.getId();
		int j = host.getId();
		if(host.getRamProvisioner().getAvailableRam()-vm.getRam()>=0
				 && host.getAvailableMips()-vm.getMips()>=0)
			return 1;
		else
			return 0;
	}

	private static double cpuUtilization(Host host) {
		return 1.0 - host.getAvailableMips() / host.getTotalMips();
	}

	private static double ramUtilization(Host host) {
		return (double)host.getRamProvisioner().getUsedRam() / host.getRamProvisioner().getRam();
	}

	private static double resourceUtilization(Host host) {
		return 1.0 - Math.sqrt((Math.pow(1.0-cpuUtilization(host),2.0)
				+Math.pow(1.0-ramUtilization(host),2.0))/2);
	}

	private static double F(Vm vm, Host host) {
		if (! host.vmCreate(vm))
			return -1.0;
		double alpha = 0.3;
		double beta = 0.4;
		double gamma = 0.3;

		double eneUti = EC(host);
		double resUti = resourceUtilization(host);
		double availability = host.getAbility();
		host.vmDestroy(vm);

		return alpha*(1-Math.pow(eneUti,2.0)) + beta*(1-Math.pow(resUti,2.0)) + gamma*availability;
	}

	//energy consumption
	private static double EC(Host host) {
		double c = 0.15;
		double f = 0.24;
		double k = 0.3;
		return c + k * Math.pow(f, 3.0) * cpuUtilization(host);
	}
}