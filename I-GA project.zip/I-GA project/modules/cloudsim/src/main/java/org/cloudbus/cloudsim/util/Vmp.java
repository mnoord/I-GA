package org.cloudbus.cloudsim.util;

import java.util.Arrays;

public class Vmp {
    public int[] codes;

    public Vmp(int size) {
        this.codes = new int[size];
    }

    public Vmp(int[] codes) {
        this.codes = new int[codes.length];
        for(int i = 0; i < codes.length; ++i) {
            this.codes[i] = codes[i];
        }
    }

    @Override
    public boolean equals(Object obj) {
//        if (this == obj)
//            return true;
//        if (obj == null)
//            return false;
//        if (getClass() != obj.getClass())
//            return false;
        Vmp other = (Vmp)obj;
        return Arrays.equals(codes, other.codes);
    }

//    @Override
//    public int hashCode(){  // 重写hashCode()方法。
//        int res = 0;
//        for (int i = 0; i < codes.length; i++) {
//            res += codes[i] * 15 * i;
//        }
//        return res;
//    }

    public static void main(String[] args) {
        Vmp v1 = new Vmp(new int[] {1,2,3});
        Vmp v2 = new Vmp(new int[] {1,2,3});
        System.out.println(v1.hashCode());
        System.out.println(v2.hashCode());
    }
}
